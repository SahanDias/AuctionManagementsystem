﻿namespace AuctionBackend.Models
{
    public class UpdartrAdminDto
    {
        public required string Name { get; set; }
        public required string Phone { get; set; }
    }
}
