﻿namespace AuctionBackend.Models
{
    public class AddAdminDto
    {
        public required string Name { get; set; }
        public required string Password { get; set; }
    }
}
