﻿namespace AuctionBackend.Models.Entities
{
    public class Item
    {
    }
}
